import java.util.ArrayList;
import java.util.Scanner;

public class SistemaClientes {
    private ArrayList<Cliente> clientes = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    private int idCounter = 1;

    public void menu() {
        int opcao;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Listar Clientes");
            System.out.println("3. Atualizar Cliente");
            System.out.println("4. Remover Cliente");
            System.out.println("5. Buscar Cliente");
            System.out.println("6. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer

            switch (opcao) {
                case 1:
                    cadastrarCliente();
                    break;
                case 2:
                    listarClientes();
                    break;
                case 3:
                    atualizarCliente();
                    break;
                case 4:
                    removerCliente();
                    break;
                case 5:
                    buscarCliente();
                    break;
                case 6:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 6);
    }

    private void cadastrarCliente() {
        System.out.print("Digite o nome: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o email: ");
        String email = scanner.nextLine();
        System.out.print("Digite o telefone: ");
        String telefone = scanner.nextLine();

        Cliente cliente = new Cliente(idCounter++, nome, email, telefone);
        clientes.add(cliente);
        System.out.println("Cliente cadastrado com sucesso!");
    }

    private void listarClientes() {
        if (clientes.isEmpty()) {
            System.out.println("Nenhum cliente cadastrado.");
        } else {
            for (Cliente cliente : clientes) {
                System.out.println(cliente);
            }
        }
    }

    private void atualizarCliente() {
        System.out.print("Digite o ID do cliente a ser atualizado: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpar o buffer

        for (Cliente cliente : clientes) {
            if (cliente.getId() == id) {
                System.out.print("Novo nome: ");
                cliente.setNome(scanner.nextLine());
                System.out.print("Novo email: ");
                cliente.setEmail(scanner.nextLine());
                System.out.print("Novo telefone: ");
                cliente.setTelefone(scanner.nextLine());
                System.out.println("Cliente atualizado com sucesso!");
                return;
            }
        }
        System.out.println("Cliente não encontrado.");
    }

    private void removerCliente() {
        System.out.print("Digite o ID do cliente a ser removido: ");
        int id = scanner.nextInt();

        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getId() == id) {
                clientes.remove(i);
                System.out.println("Cliente removido com sucesso!");
                return;
            }
        }
        System.out.println("Cliente não encontrado.");
    }

    private void buscarCliente() {
        System.out.print("Digite o ID do cliente a ser buscado: ");
        int id = scanner.nextInt();

        for (Cliente cliente : clientes) {
            if (cliente.getId() == id) {
                System.out.println(cliente);
                return;
            }
        }
        System.out.println("Cliente não encontrado.");
    }

    public static void main(String[] args) {
        SistemaClientes sistema = new SistemaClientes();
        sistema.menu();
    }
}
